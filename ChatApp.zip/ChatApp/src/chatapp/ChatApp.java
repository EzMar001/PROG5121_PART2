package chatapp;

import javax.swing.*;
import java.util.*;
import java .io.FileWriter;
import java.io.IOException;
 

public class ChatApp {
static String registeredUsername;
static String registeredPassword;
static String registeredPhone;
static int totalMessageSent = 0;
static int messageNumber = 0;
    public static void main(String[] args) {
       //Display the Welcome message ahead  registration
       JOptionPane.showMessageDialog(null,  "Welcome to ChatApp");
       registerUser();
       
       // If credentials are correct , continue to login
       if (loginUser()){
           JOptionPane.showMessageDialog(null, "Login successful.Redirecting to ChatApp....");
           runMessageSystem();
       } else{
           JOptionPane.showMessageDialog(null, "Login failed.Exiting app.");
       }
    }
    public static void registerUser() {
        boolean valid = false;
        
        while (!valid) {
            //Validates username
            registeredUsername = JOptionPane.showInputDialog("Create a username(must contain _ and max 5 chars:");
            if (!(registeredUsername.contains("_") && registeredUsername.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue; 
            }
            //Validates password
            registeredPhone = JOptionPane.showInputDialog("Create password(8+ chars, 1 capital characters long, contain an uppercase letter, number and special characters");
                    if (!registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
                        JOptionPane.showMessageDialog(null, "Invalid password.");
                        continue ;
                    }
                    //Validates cellphone number
                    registeredPhone = JOptionPane.showInputDialog("Enter phone number (+ +27xxxxxxxxxx");
                    if (!registeredPhone.matches("^\\+27[6-8]\\d{8}")) {
                        JOptionPane.showMessageDialog(null,"Invalid phone.");
                        continue;
                    }
                    
                    JOptionPane.showMessageDialog(null, "Registration successful");
                    valid = true;                         
        }
        
    }
             //Checks login details against the registered ones
    public static boolean loginUser(){
        String user = JOptionPane.showInputDialog("Login - Entter your username :");
        String pass = JOptionPane.showInputDialog("Enter your password:");
        
        return user.equals(registeredUsername) && pass.equals(registeredPassword);
    }
    //Display the main menu for the Chat
    public static void runMessageSystem() {
        boolean keepRunning = true;
         
        while (keepRunning) {
            String[] options = {"Send Messages", "Coming Soon", "Quit"};
            int choice = JOptionPane.showOptionDialog(null,"Choose an option :", "Main Menu",
                    JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE,null,options, options[0]);
            
            switch (choice) {
                case 0 -> sendMessages(); //redirects to sending
                case 1 -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                case 2 -> {
                    keepRunning = false ;
                    JOptionPane.showMessageDialog(null, "Goodbye!"); //Exit Chat Application
                }
            }
           
            
        }
    }
   //Allow multiple messages to be sent and controlled by the user
    public static void sendMessages() {
        int count = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to send?"));
        
        for (int i = 0; i < count; i++) {
            messageNumber++;
            String messageID = generateMessageID();
            //Validates recipient's South African number
            String recipient = JOptionPane.showInputDialog("Enter recipient number(+27xxxxxxxxxx):");
            if (!recipient.matches("^\\+27\\d{9}$")){
            JOptionPane.showMessageDialog(null, "Invalid number format.");
            i--;
            continue ;
        }
             //Limits message to 250 characters
             String message = JOptionPane.showInputDialog("Enter messsage(max 250 characters)");
             if (message.length()> 250) {
                 JOptionPane.showMessageDialog(null,"Message too long by" + (message.length() - 250) + "characters.");
                 i--;
                 continue;
             }
             String hash = generateMessageHash(messageID,messageNumber, message);
             // Allows the user to choose what to do with the message
             String[]actions = {"Send", "Disregard", "Store"};
             int action = JOptionPane.showOptionDialog(null,"What do you want to do?", "Message Options",
              JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE,null, actions,actions[0]);
             
             switch(action) {
                 case 0 -> {
                    totalMessagesSent++;
                     displayMessageDetails(messageID, hash, recipient, message);
                     JOptionPane.showMessageDialog(null,"Message successfully sent.");
                     }
                 case 1 -> JOptionPane.showMessageDialog(null, "Message disregarded.");
                 case 2 -> {
                     writeMessageToJSON(messageID,hash, recipient, message);
                     JOptionPane.showMessageDialog(null, "Message stored");
                     
                 }
             }
    }
        JOptionPane.showMessageDialog(null, "Total messages sent:" + totalMessageSent);
    }
    //Generates a random 10-digit message ID
    public static String generateMessageID() {
        return String.format("%01d",new Random().nextInt(1_000_000_000));       
    }
    //Crreates a simple hash for each message
    public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words[0];
   String last = words[words.length -1];
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }
    //Display the details  of the sent message
    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "Message ID :" + id +
                        "\nHash" + hash +
                        "\nRecipient:" + recipient +
                        "\nMessage:" + message);
        
    }
    //Simulates JSON writing without external libraries
    public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
     StringBuilder jsonEntry = new StringBuilder();
     jsonEntry.append("{\n");
     jsonEntry.append(" \"MessageID\": \"").append(messageID).append("\",\n");
     jsonEntry.append(" \"MessageHash\": \"").append(hash).append("\",\n");
     jsonEntry.append(" \"Recipient\":\"").append(recipient).append("\",\n");
     jsonEntry.append(" \"Message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
     jsonEntry.append("},\n");
     
     try (FileWriter file = new FileWriter("Jsonnew.json",true)) { //append mode
         file.write(jsonEntry.toString());
     } catch (IOException e) {
         JOptionPane.showMessageDialog(null,"Error writing file:" + e.getMessage());
         
     }
        
    }
    
    }

